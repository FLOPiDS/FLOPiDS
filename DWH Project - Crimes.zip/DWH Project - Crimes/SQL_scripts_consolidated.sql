/* LOADING STA_DEPARTMENT TABLE */
CREATE TABLE [Department] (
    [Code Postal] varchar(255),
    [D�partement] varchar(255),
    [Indicatif T�l�phonique ] varchar(255),
    [R�gion] varchar(255),
    [Zone Vacances] varchar(255)
)
/* LOADING STA_CRIMES TABLE */
CREATE TABLE [Crimes] (
    [Index] float,
    [Libell� index] nvarchar(255),
    [2016_03] float,
    [2016_02] float,
    [2016_01] float,
    [2015_12] float,
    [2015_11] float,
    [2015_10] float,
    [2015_09] float,
    [2015_08] float,
    [2015_07] float,
    [2015_06] float,
    [2015_05] float,
    [2015_04] float,
    [2015_03] float,
    [2015_02] float,
    [2015_01] float,
    [2014_12] float,
    [2014_11] float,
    [2014_10] float,
    [2014_09] float,
    [2014_08] float,
    [2014_07] float,
    [2014_06] float,
    [2014_05] float,
    [2014_04] float,
    [2014_03] float,
    [2014_02] float,
    [2014_01] float,
    [2013_12] float,
    [2013_11] float,
    [2013_10] float,
    [2013_09] float,
    [2013_08] float,
    [2013_07] float,
    [2013_06] float,
    [2013_05] float,
    [2013_04] float,
    [2013_03] float,
    [2013_02] float,
    [2013_01] float,
    [2012_12] float,
    [2012_11] float,
    [2012_10] float,
    [2012_09] float,
    [2012_08] float,
    [2012_07] float,
    [2012_06] float,
    [2012_05] float,
    [2012_04] float,
    [2012_03] float,
    [2012_02] float,
    [2012_01] float,
    [2011_12] float,
    [2011_11] float,
    [2011_10] float,
    [2011_09] float,
    [2011_08] float,
    [2011_07] float,
    [2011_06] float,
    [2011_05] float,
    [2011_04] float,
    [2011_03] float,
    [2011_02] float,
    [2011_01] float,
    [2010_12] float,
    [2010_11] float,
    [2010_10] float,
    [2010_09] float,
    [2010_08] float,
    [2010_07] float,
    [2010_06] float,
    [2010_05] float,
    [2010_04] float,
    [2010_03] float,
    [2010_02] float,
    [2010_01] float,
    [2009_12] float,
    [2009_11] float,
    [2009_10] float,
    [2009_09] float,
    [2009_08] float,
    [2009_07] float,
    [2009_06] float,
    [2009_05] float,
    [2009_04] float,
    [2009_03] float,
    [2009_02] float,
    [2009_01] float,
    [2008_12] float,
    [2008_11] float,
    [2008_10] float,
    [2008_09] float,
    [2008_08] float,
    [2008_07] float,
    [2008_06] float,
    [2008_05] float,
    [2008_04] float,
    [2008_03] float,
    [2008_02] float,
    [2008_01] float,
    [2007_12] float,
    [2007_11] float,
    [2007_10] float,
    [2007_09] float,
    [2007_08] float,
    [2007_07] float,
    [2007_06] float,
    [2007_05] float,
    [2007_04] float,
    [2007_03] float,
    [2007_02] float,
    [2007_01] float,
    [2006_12] float,
    [2006_11] float,
    [2006_10] float,
    [2006_09] float,
    [2006_08] float,
    [2006_07] float,
    [2006_06] float,
    [2006_05] float,
    [2006_04] float,
    [2006_03] float,
    [2006_02] float,
    [2006_01] float,
    [2005_12] float,
    [2005_11] float,
    [2005_10] float,
    [2005_09] float,
    [2005_08] float,
    [2005_07] float,
    [2005_06] float,
    [2005_05] float,
    [2005_04] float,
    [2005_03] float,
    [2005_02] float,
    [2005_01] float,
    [2004_12] float,
    [2004_11] float,
    [2004_10] float,
    [2004_09] float,
    [2004_08] float,
    [2004_07] float,
    [2004_06] float,
    [2004_05] float,
    [2004_04] float,
    [2004_03] float,
    [2004_02] float,
    [2004_01] float,
    [2003_12] float,
    [2003_11] float,
    [2003_10] float,
    [2003_09] float,
    [2003_08] float,
    [2003_07] float,
    [2003_06] float,
    [2003_05] float,
    [2003_04] float,
    [2003_03] float,
    [2003_02] float,
    [2003_01] float,
    [2002_12] float,
    [2002_11] float,
    [2002_10] float,
    [2002_09] float,
    [2002_08] float,
    [2002_07] float,
    [2002_06] float,
    [2002_05] float,
    [2002_04] float,
    [2002_03] float,
    [2002_02] float,
    [2002_01] float,
    [2001_12] float,
    [2001_11] float,
    [2001_10] float,
    [2001_09] float,
    [2001_08] float,
    [2001_07] float,
    [2001_06] float,
    [2001_05] float,
    [2001_04] float,
    [2001_03] float,
    [2001_02] float,
    [2001_01] float,
    [2000_12] float,
    [2000_11] float,
    [2000_10] float,
    [2000_09] float,
    [2000_08] float,
    [2000_07] float,
    [2000_06] float,
    [2000_05] float,
    [2000_04] float,
    [2000_03] float,
    [2000_02] float,
    [2000_01] float,
    [1999_12] float,
    [1999_11] float,
    [1999_10] float,
    [1999_09] float,
    [1999_08] float,
    [1999_07] float,
    [1999_06] float,
    [1999_05] float,
    [1999_04] float,
    [1999_03] float,
    [1999_02] float,
    [1999_01] float,
    [1998_12] float,
    [1998_11] float,
    [1998_10] float,
    [1998_09] float,
    [1998_08] float,
    [1998_07] float,
    [1998_06] float,
    [1998_05] float,
    [1998_04] float,
    [1998_03] float,
    [1998_02] float,
    [1998_01] float,
    [1997_12] float,
    [1997_11] float,
    [1997_10] float,
    [1997_09] float,
    [1997_08] float,
    [1997_07] float,
    [1997_06] float,
    [1997_05] float,
    [1997_04] float,
    [1997_03] float,
    [1997_02] float,
    [1997_01] float,
    [1996_12] float,
    [1996_11] float,
    [1996_10] float,
    [1996_09] float,
    [1996_08] float,
    [1996_07] float,
    [1996_06] float,
    [1996_05] float,
    [1996_04] float,
    [1996_03] float,
    [1996_02] float,
    [1996_01] float,
    [DeptCode] nvarchar(6)
)
/* LOADING ODS_DEPARTMENT TABLE */
CREATE TABLE [Department] (
    [Code Postal_6] nvarchar(6),
    [D�partement_50] nvarchar(50),
    [R�gion_50] nvarchar(50)
)

/* CREATING STA_TECHNICAL_REJECTS TABLE */
CREATE TABLE [TechnicalRejects] (
    [Error_date] datetime,
    [Error_pkg] nvarchar(23),
    [Error_msg] nvarchar(30),
    [Error_col] nvarchar(5)
)

/* LOADING ODS_LIBELLE TABLE */
CREATE TABLE [Libelle] (
    [Index_INT] int,
    [Libell�_1000] nvarchar(1000)
)

/* LOADING ODS_CRIMES TABLE */
CREATE TABLE [Crimes] (
    [Index] int,
    [Period] datetime,
    [Value] int,
    [DeptCode] nvarchar(10)
)

/* Creating DimDepartment table */
CREATE TABLE [dbo].[DimDepartment](
	DepartmentKey INT PRIMARY KEY IDENTITY (1,1),
	[Code Postal] [nvarchar](6) NULL,
	[D�partement] [nvarchar](50) NULL,
	[R�gion] [nvarchar](50) NULL
) ON [PRIMARY]
/* Updating a row in DimDepartment table */
UPDATE [dbo].[DimDepartment]
   SET [D�partement] = ?
      ,[R�gion] = ?
 WHERE [Code Postal] = ?

/* Creating DimLibelle table */
CREATE TABLE [dbo].[DimLibelle](
	LibelleKey INT PRIMARY KEY IDENTITY(1,1),
	[Index] [int] NULL,
	[Libell�] [nvarchar](1000) NULL
) ON [PRIMARY]
/* Updating a row in DimLibelle table */
UPDATE [dbo].[DimLibelle]
   SET [Libell�] = ?
 WHERE [Index] = ?

 /* Creating FactCrimes table */
 CREATE TABLE [FactCrimes] (
    CrimesKey INT PRIMARY KEY IDENTITY (1,1),
    [DepartmentKey] int,
    [LibelleKey] int,
    [DeptCode] nvarchar(10),
    [Index] int,
    [Period] datetime,
    [Value] int

/* Creating DimDate table */
CREATE TABLE dbo.DimDate (
   DateKey INT NOT NULL PRIMARY KEY,
   [Date] DATETIME NOT NULL,
   [Day] TINYINT NOT NULL,
   [DaySuffix] CHAR(2) NOT NULL,
   [Weekday] TINYINT NOT NULL,
   [WeekDayName] VARCHAR(10) NOT NULL,
   [WeekDayName_Short] CHAR(3) NOT NULL,
   [WeekDayName_FirstLetter] CHAR(1) NOT NULL,
   [DOWInMonth] TINYINT NOT NULL,
   [DayOfYear] SMALLINT NOT NULL,
   [WeekOfMonth] TINYINT NOT NULL,
   [WeekOfYear] TINYINT NOT NULL,
   [Month] TINYINT NOT NULL,
   [MonthName] VARCHAR(10) NOT NULL,
   [MonthName_Short] CHAR(3) NOT NULL,
   [MonthName_FirstLetter] CHAR(1) NOT NULL,
   [Quarter] TINYINT NOT NULL,
   [QuarterName] VARCHAR(6) NOT NULL,
   [Year] INT NOT NULL,
   [MMYYYY] CHAR(6) NOT NULL,
   [MonthYear] CHAR(7) NOT NULL,
   IsWeekend BIT NOT NULL,
   )

  
   GO


   SET NOCOUNT ON

TRUNCATE TABLE DimDate

DECLARE @CurrentDate DATE = '2010-01-01'
DECLARE @EndDate DATE = '2020-12-31'

WHILE @CurrentDate < @EndDate
BEGIN
   INSERT INTO [dbo].[DimDate] (
      [DateKey],
      [Date],
      [Day],
      [DaySuffix],
      [Weekday],
      [WeekDayName],
      [WeekDayName_Short],
      [WeekDayName_FirstLetter],
      [DOWInMonth],
      [DayOfYear],
      [WeekOfMonth],
      [WeekOfYear],
      [Month],
      [MonthName],
      [MonthName_Short],
      [MonthName_FirstLetter],
      [Quarter],
      [QuarterName],
      [Year],
      [MMYYYY],
      [MonthYear],
      [IsWeekend]
      )
   SELECT DateKey = YEAR(@CurrentDate) * 10000 + MONTH(@CurrentDate) * 100 + DAY(@CurrentDate),
      DATE = @CurrentDate,
      Day = DAY(@CurrentDate),
      [DaySuffix] = CASE 
         WHEN DAY(@CurrentDate) = 1
            OR DAY(@CurrentDate) = 21
            OR DAY(@CurrentDate) = 31
            THEN 'st'
         WHEN DAY(@CurrentDate) = 2
            OR DAY(@CurrentDate) = 22
            THEN 'nd'
         WHEN DAY(@CurrentDate) = 3
            OR DAY(@CurrentDate) = 23
            THEN 'rd'
         ELSE 'th'
         END,
      WEEKDAY = DATEPART(dw, @CurrentDate),
      WeekDayName = DATENAME(dw, @CurrentDate),
      WeekDayName_Short = UPPER(LEFT(DATENAME(dw, @CurrentDate), 3)),
      WeekDayName_FirstLetter = LEFT(DATENAME(dw, @CurrentDate), 1),
      [DOWInMonth] = DAY(@CurrentDate),
      [DayOfYear] = DATENAME(dy, @CurrentDate),
      [WeekOfMonth] = DATEPART(WEEK, @CurrentDate) - DATEPART(WEEK, DATEADD(MM, DATEDIFF(MM, 0, @CurrentDate), 0)) + 1,
      [WeekOfYear] = DATEPART(wk, @CurrentDate),
      [Month] = MONTH(@CurrentDate),
      [MonthName] = DATENAME(mm, @CurrentDate),
      [MonthName_Short] = UPPER(LEFT(DATENAME(mm, @CurrentDate), 3)),
      [MonthName_FirstLetter] = LEFT(DATENAME(mm, @CurrentDate), 1),
      [Quarter] = DATEPART(q, @CurrentDate),
      [QuarterName] = CASE 
         WHEN DATENAME(qq, @CurrentDate) = 1
            THEN 'First'
         WHEN DATENAME(qq, @CurrentDate) = 2
            THEN 'second'
         WHEN DATENAME(qq, @CurrentDate) = 3
            THEN 'third'
         WHEN DATENAME(qq, @CurrentDate) = 4
            THEN 'fourth'
         END,
      [Year] = YEAR(@CurrentDate),
      [MMYYYY] = RIGHT('0' + CAST(MONTH(@CurrentDate) AS VARCHAR(2)), 2) + CAST(YEAR(@CurrentDate) AS VARCHAR(4)),
      [MonthYear] = CAST(YEAR(@CurrentDate) AS VARCHAR(4)) + UPPER(LEFT(DATENAME(mm, @CurrentDate), 3)),
      [IsWeekend] = CASE 
         WHEN DATENAME(dw, @CurrentDate) = 'Sunday'
            OR DATENAME(dw, @CurrentDate) = 'Saturday'
            THEN 1
         ELSE 0
         END

   SET @CurrentDate = DATEADD(DD, 1, @CurrentDate)
END

